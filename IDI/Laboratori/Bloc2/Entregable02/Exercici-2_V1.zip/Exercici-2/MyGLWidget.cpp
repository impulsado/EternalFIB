#include "MyGLWidget.h"
#include <iostream>
#include <stdio.h>

#define printOpenGLError() printOglError(__FILE__, __LINE__)
#define CHECK() printOglError(__FILE__, __LINE__,__FUNCTION__)
#define DEBUG() std::cout << __FILE__ << " " << __LINE__ << " " << __FUNCTION__ << std::endl;

MyGLWidget::MyGLWidget(QWidget *parent=0) : LL2GLWidget(parent) {
  connect(&timer, SIGNAL(timeout()), this, SLOT(updatePosition()));
}

int MyGLWidget::printOglError(const char file[], int line, const char func[]) 
{
    GLenum glErr;
    int    retCode = 0;

    glErr = glGetError();
    const char * error = 0;
    switch (glErr)
    {
        case 0x0500:
            error = "GL_INVALID_ENUM";
            break;
        case 0x501:
            error = "GL_INVALID_VALUE";
            break;
        case 0x502: 
            error = "GL_INVALID_OPERATION";
            break;
        case 0x503:
            error = "GL_STACK_OVERFLOW";
            break;
        case 0x504:
            error = "GL_STACK_UNDERFLOW";
            break;
        case 0x505:
            error = "GL_OUT_OF_MEMORY";
            break;
        default:
            error = "unknown error!";
    }
    if (glErr != GL_NO_ERROR)
    {
        printf("glError in file %s @ line %d: %s function: %s\n",
                             file, line, error, func);
        retCode = 1;
    }
    return retCode;
}

MyGLWidget::~MyGLWidget()
{
}

void MyGLWidget::reset() {
  videocamera_on = false;
  direccio_nord = true;
  animacio_on = false;
  timer.stop();
  
  initializeGL();
  paintGL();
  viewTransform();
  projectTransform();
}

void MyGLWidget::updateVideoCamParams() {
  camera_videocam.VRP = rick.posicio;
  camera_videocam.zF = 10.f;   // FERRR: Veure quin es el zF que veu la escena completa sempre
  viewTransform();
}

void MyGLWidget::detectarObrirPorta() {
  if (-2.0f <= rick.posicio.x  && rick.posicio.x <= 2.0f) {
    porta.posicio.z = 2.0f - glm::abs(rick.posicio.x);
  }
}

void MyGLWidget::keyPressEvent(QKeyEvent* event) {
  makeCurrent();
  switch (event->key()) {
    case Qt::Key_Up: {
      if (rick.posicio.x < 5.5f) {
        rick.posicio += glm::vec3(0.25f, 0.0f, 0.0f);
        rick.rotacioY = glm::radians(90.0f);
        direccio_nord = true;
        detectarObrirPorta();
      }
      break;
    }
    case Qt::Key_Down: {
      if (rick.posicio.x > -5.5f) {
        rick.posicio += glm::vec3(-0.25f, 0.0f, 0.0f);
        rick.rotacioY = -glm::radians(90.0f);
        direccio_nord = false;
        detectarObrirPorta();
      }
      break;
    }           
    case Qt::Key_C: { 
      videocamera_on = !videocamera_on;
      projectTransform();
      viewTransform();
      break;
    }           
    case Qt::Key_A: { 
      animacio_on = !animacio_on;
      if (animacio_on) timer.start(100);
      else timer.stop();
      break;
    }  
    case Qt::Key_R: {
      reset();
      break;
    }  
    default: event->ignore(); break;
  }
  if (videocamera_on) updateVideoCamParams();
  update();
}

void MyGLWidget::updatePosition() {
  // NOTA: Si no fiques aixo no s'actualitza el update();
  makeCurrent();

  // Actualitzar Posició
  if (direccio_nord) {
    if (rick.posicio.x == 5.5f) {
      direccio_nord = !direccio_nord;
      rick.rotacioY = -glm::radians(90.0f);
    }
    else rick.posicio += glm::vec3(0.25f, 0.0f, 0.0f);
  }
  else {
    if (rick.posicio.x == -5.5f) {
      direccio_nord = !direccio_nord;
      rick.rotacioY = glm::radians(90.0f);
    }
    else rick.posicio += glm::vec3(-0.25f, 0.0f, 0.0f);
  }

  // Actualitzar Porta
  detectarObrirPorta();

  // Actualitzar Vista
  modelTransformRick();
  if (videocamera_on) updateVideoCamParams();
  update();
}

void MyGLWidget::modelTransformTerra () {
  glm::mat4 TG(1.0f);
  TG = glm::scale(TG, glm::vec3(terra.escalaX, 1.0f, 1.0f));
  glUniformMatrix4fv (transLoc, 1, GL_FALSE, &TG[0][0]);
  glUniform1ui(esPortaLoc, 0);
}

void MyGLWidget::modelTransformRick () {
  glm::mat4 TG(1.0f);
  TG = glm::translate(TG, rick.posicio);
  TG = glm::rotate(TG, rick.rotacioY, glm::vec3(0.0f, 1.0f, 0.0f));
  TG = glm::scale(TG, glm::vec3(rick.escala, rick.escala, rick.escala));
  TG = glm::translate(TG, -rick.centre_base);
  glUniformMatrix4fv(transLoc, 1, GL_FALSE, &TG[0][0]);
  glUniform1ui(esPortaLoc, 0);
}

void MyGLWidget::modelTransformVideocamera () {
  glm::mat4 TG(1.0f);
  TG = glm::translate(TG, videocamera.posicio);
  TG = glm::rotate(TG, videocamera.rotacioY, glm::vec3(0.0f, 1.0f, 0.0f));
  TG = glm::rotate(TG, videocamera.rotacioX, glm::vec3(1.0f, 0.0f, 0.0f));
  TG = glm::scale(TG, glm::vec3(videocamera.escala));
  TG = glm::translate(TG, -videocamera.centre_base);
  glUniformMatrix4fv (transLoc, 1, GL_FALSE, &TG[0][0]);
  glUniform1ui(esPortaLoc, 0);
}

void MyGLWidget::modelTransformCub (Figura& model) {
  glm::mat4 TG(1.0f);
  TG = glm::translate(TG, model.posicio);  // 3. Portar posicio final
  TG = glm::scale(TG, glm::vec3 (model.escalaX, model.escalaY, model.escalaZ));  // 2. Ajustar mides
  glUniformMatrix4fv (transLoc, 1, GL_FALSE, &TG[0][0]);
  if (model.escalaY == 1.9f) glUniform1ui(esPortaLoc, 1);
  else glUniform1ui(esPortaLoc, 0);
}

void MyGLWidget::paintGL () {
  // descomentar per canviar paràmetres
  // glViewport (0, 0, ample, alt);

  // Esborrem el frame-buffer
  glClear (GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

  // Rick
  glBindVertexArray (VAO_Rick);
  modelTransformRick ();
  glDrawArrays(GL_TRIANGLES, 0, rick.model.faces().size()*3);

  // Video Camera
  if (!videocamera_on) {
    glBindVertexArray (VAO_VideoCam);
    modelTransformVideocamera ();
    glDrawArrays(GL_TRIANGLES, 0, videocamera.model.faces().size()*3);
  }
  
  // Cub
  glBindVertexArray (VAO_Cub);
  // Paret1
  modelTransformCub (paret1);
  glDrawArrays(GL_TRIANGLES, 0, 36);
  // Paret2
  modelTransformCub (paret2);
  glDrawArrays(GL_TRIANGLES, 0, 36);
  // Porta
  modelTransformCub (porta);
  glDrawArrays(GL_TRIANGLES, 0, 36);

  // Terra
  glBindVertexArray (VAO_Terra);
  modelTransformTerra ();
  glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);

  glBindVertexArray (0);
}

void MyGLWidget::calcAtributsFigura(Figura& model) {
  glm::vec3 temp_pmin = glm::vec3(MAXFLOAT);
  glm::vec3 temp_pmax = glm::vec3(-MAXFLOAT);

  for (u_int i = 0; i < model.model.vertices().size(); i+=3) {
      temp_pmin.x = fmin(temp_pmin.x, model.model.vertices()[i+0]);
      temp_pmax.x = fmax(temp_pmax.x, model.model.vertices()[i+0]);
  
      temp_pmin.y = fmin(temp_pmin.y, model.model.vertices()[i+1]);
      temp_pmax.y = fmax(temp_pmax.y, model.model.vertices()[i+1]);

      temp_pmin.z = fmin(temp_pmin.z, model.model.vertices()[i+2]);
      temp_pmax.z = fmax(temp_pmax.z, model.model.vertices()[i+2]);
  }

  model.pmin = temp_pmin;
  model.pmax = temp_pmax;
  model.centre = glm::vec3((temp_pmin.x+temp_pmax.x)/2.0f, (temp_pmin.y+temp_pmax.y)/2.0f, (temp_pmin.z+temp_pmax.z)/2.0f);
  model.centre_base = glm::vec3((temp_pmin.x+temp_pmax.x)/2.0f, temp_pmin.y, (temp_pmin.z+temp_pmax.z)/2.0f);
  model.radi = glm::distance(temp_pmin, temp_pmax)/2.0f;
  model.alçada = temp_pmax.y-temp_pmin.y;
}

void MyGLWidget::iniFigures() {
  // Rick
  rick.model.load("./models/Rick.obj");
  calcAtributsFigura(rick);
  rick.escala = 1.5f/rick.alçada;
  rick.posicio = glm::vec3(-5.0f, 0.0f, 0.0f);
  rick.rotacioY = glm::radians(90.0f);
  
  // VideoCamera
  videocamera.model.load("./models/VideoCamera.obj");
  calcAtributsFigura(videocamera);
  videocamera.escala = 0.4f/videocamera.alçada;
  videocamera.posicio = glm::vec3(0.0f, 2.0f, -1.0f);
  videocamera.rotacioX = glm::radians(30.0f);
  videocamera.rotacioY = -glm::radians(80.0f);

  // Terra
  terra.escalaX = 1.5f;  // En X només

  // Paret1 i Paret2
  paret1.posicio = glm::vec3(0.0f, 0.0f, -2.5f);
  paret2.posicio = glm::vec3(0.0f, 0.0f, 2.5f);
  paret1.escalaX = paret2.escalaX = 0.5f;
  paret1.escalaY = paret2.escalaY = 2.0f;
  paret1.escalaZ = paret2.escalaZ = 3.0f;

  // Porta
  porta.posicio = glm::vec3(0.0f, 0.0f, 0.0f);
  porta.escalaX = 0.25f;
  porta.escalaY = 1.9f;
  porta.escalaZ = 2.0f;
}

void MyGLWidget::iniEscena() {
  // NOTA: Punts calculats a mà
  escena_global.pmin = glm::vec3(-6.0f, 0.0f, -4.0f);
  escena_global.pmax = glm::vec3(6.0f, 2.0f, 4.0f);
  escena_global.centre = glm::vec3((escena_global.pmin.x+escena_global.pmax.x)/2.0f, (escena_global.pmin.y+escena_global.pmax.y)/2.0f, (escena_global.pmin.z+escena_global.pmax.z)/2.0f);
  escena_global.radi = glm::distance(escena_global.centre, escena_global.pmax);
}

void MyGLWidget::iniCamera() {
  // GENERAL
  // d = 2*R
  float R = escena_global.radi;
  float d = 2*R;
  camera_global.d = d;

  // zN = d-R ; zF = d+R
  camera_global.zN = d-R;
  camera_global.zF = d+R;

  // VRP = Centre
  camera_global.VRP = escena_global.centre;
  // OBS = OG + (0,0,d)
  // NOTA: Elevo +1 la Y per no veure-ho paral·lel a Z
  camera_global.OBS = glm::vec3(0.0f) + glm::vec3(0.0f, 1.0f, d);
  // UP = (0,1,0)
  camera_global.UP = glm::vec3(0.0f, 1.0f, 0.0f);

  // PERSPECTIVA
  // FOV_optim = arcsin(R/d);
  camera_global.FOV_optim = camera_global.FOV_act = 2.0f*glm::asin(R/d);
  // ra (SEMPRE >=1.0f --> Per defecte 1)
  camera_global.ra = 1.0f;

  // EULER
  camera_global.yaw = glm::radians(45.0f);
  camera_global.pitch = glm::radians(45.0f);
  
  viewTransform();
}

void MyGLWidget::iniVideoCamera() {  
  // OBS: posicion fijo de la videocámara
  camera_videocam.OBS = glm::vec3(0.0f, 2.25f, -1.0f);
  
  // VRP: apuntamos al centro base de Rick, para que se mantenga en el centro de la vista
  camera_videocam.VRP = rick.posicio;
  
  // Calcular la distancia entre el OBS de la videocámara y el VRP (Rick)
  float d = glm::distance(camera_videocam.OBS, camera_videocam.VRP);
  
  // Establecer los planos de recorte
  // Se define el plano cercano como la distancia d menos el radio de Rick (asegurando un mínimo para evitar planos muy cercanos)
  camera_videocam.zN = 0.01f;
  // El plano lejano se define como la distancia d más el radio de Rick
  camera_videocam.zF = d + rick.radi;
  
  // Perspectiva: se establece un FOV de 90° (convertido a radianes) y una razón de aspecto por defecto 1.0
  camera_videocam.FOV_optim = camera_videocam.FOV_act = 90.0f;
  camera_videocam.ra = 1.0f;
  
  // Vector UP permanece igual
  camera_videocam.UP = glm::vec3(0.0f, 1.0f, 0.0f);
  
  // Actualizar la vista de inmediato
  viewTransform();
}

void MyGLWidget::resizeGL(int w, int h) {
  LL2GLWidget::resizeGL(w,h);

  act_ra_viewport = float(w)/float(h);
  camera_global.ra = act_ra_viewport;
  camera_videocam.ra = act_ra_viewport;

  if (act_ra_viewport < 1) {
    camera_global.FOV_act = 2 * glm::atan(glm::tan(camera_global.FOV_optim/2)/act_ra_viewport);
    camera_videocam.FOV_act = 2 * glm::atan(glm::tan(camera_videocam.FOV_optim/2)/act_ra_viewport);
  }
}

void MyGLWidget::initializeGL () {
  LL2GLWidget::initializeGL();

  esPortaLoc = glGetUniformLocation(program->programId(), "esPorta");
  iniEscena();
  iniCamera();
  iniFigures();
  iniVideoCamera();
}

void MyGLWidget::viewTransform () {
  // Matriu de posició i orientació de l'observador
  glm::mat4 VM(1.0f);
  if (!videocamera_on) {
    VM = glm::translate(VM, glm::vec3(0.0f, 0.0f, -camera_global.d));
    VM = glm::rotate(VM, -camera_global.roll, glm::vec3(0.0f, 0.0f, 1.0f));
    VM = glm::rotate(VM, camera_global.pitch, glm::vec3(1.0f, 0.0f, 0.0f));
    VM = glm::rotate(VM, -camera_global.yaw, glm::vec3(0.0f, 1.0f, 0.0f));  
    VM = glm::translate(VM, -camera_global.VRP);
  }
  else {
    VM = glm::lookAt(camera_videocam.OBS, camera_videocam.VRP, camera_videocam.UP);
  }
  glUniformMatrix4fv (viewLoc, 1, GL_FALSE, &VM[0][0]);
}

void MyGLWidget::projectTransform () {
  glm::mat4 PM(1.0f);
  if (!videocamera_on) PM = glm::perspective(camera_global.FOV_act, camera_global.ra, camera_global.zN, camera_global.zF);
  else PM = glm::perspective(camera_videocam.FOV_act, camera_videocam.ra, camera_videocam.zN, camera_videocam.zF);
  
  glUniformMatrix4fv (projLoc, 1, GL_FALSE, &PM[0][0]);
}

void MyGLWidget::mousePressEvent (QMouseEvent *e) {
  makeCurrent();
  LL2GLWidget::mousePressEvent(e);
}

void MyGLWidget::mouseReleaseEvent(QMouseEvent *e) {
  makeCurrent();
  LL2GLWidget::mouseReleaseEvent(e);
}

void MyGLWidget::mouseMoveEvent(QMouseEvent *e) {
  makeCurrent();

  // "Horitzontal" el ratolí
  camera_global.yaw -= (e->x() - xClick)*factorAngleY;
  // "Vertical" el ratolí
  camera_global.pitch += (e->y() - yClick)*factorAngleX;
  
  xClick = e->x();
  yClick = e->y();

  // NOTA: El "update()" no funciona xd
  viewTransform(); // Sense aixo no funciona 
  update();
}