#include "LL2GLWidget.h"

#include <vector>

#include <QTimer>

class MyGLWidget : public LL2GLWidget {
  Q_OBJECT

  public:
    MyGLWidget(QWidget *parent);
    ~MyGLWidget();

  protected:
    // STRUCTS
    struct Figura {
      Model model;
      glm::vec3 centre;
      glm::vec3 centre_base;
      glm::vec3 pmin;
      glm::vec3 pmax;
      float radi;

      float rotacioX = 0.0f;
      float rotacioY = 0.0f;
      float rotacioZ = 0.0f;

      float alçada;
      glm::vec3 posicio;
      float escala = 1.0f;  // General
      float escalaX, escalaY, escalaZ;
    };

    struct Escena {
      glm::vec3 centre;
      glm::vec3 pmin;
      glm::vec3 pmax;
      float radi;
    };

    struct Camera {
      // GENERAL
      glm::vec3 OBS;
      glm::vec3 VRP;
      glm::vec3 UP;
      float zN, zF;

      // PERSPECTIVA
      float FOV_optim;
      float FOV_act;
      float ra;
      float d;

      // EULER
      float yaw;  // 1. [Ψ | EixY] [PSI | YAW] (Negatiu)
      float pitch;  // 2. [θ | EixX] [THETA | PITCH]
      float roll;  // 3. [φ | Z] [PHI | ROLL] (Negatiu)
    };

    // FUNCTIONS
    // keyPressEvent - És cridat quan es prem una tecla
    virtual void keyPressEvent (QKeyEvent *event);
    // mouse{Press/Release/Move}Event - Són cridades quan es realitza l'event
    // corresponent de ratolí
    virtual void mousePressEvent (QMouseEvent *event);
    virtual void mouseReleaseEvent (QMouseEvent *event);
    virtual void mouseMoveEvent (QMouseEvent *event);
    // Altres
    virtual void modelTransformTerra ();
    virtual void modelTransformRick ();
    virtual void modelTransformCub (Figura& model);
    virtual void modelTransformVideocamera ();
    virtual void paintGL ();
    virtual void initializeGL ();
    virtual void resizeGL (int w, int h);
    virtual void viewTransform ();
    virtual void projectTransform ();
    
    void calcAtributsFigura(Figura& model);
    void iniEscena();
    void iniCamera();
    void iniVideoCamera();
    void iniFigures();
    void detectarObrirPorta();
    void updateVideoCamParams();
    void reset();

    // MOVIMENT
    QTimer timer;

    // VARIABLES GLOBAL
    struct Figura rick;
    struct Figura terra;
    struct Figura videocamera;
    struct Figura paret1, paret2;
    struct Figura porta;
    GLuint esPortaLoc;
    struct Escena escena_global;
    struct Camera camera_global;
    struct Camera camera_videocam;
    float act_ra_viewport = 1.0f;
    bool videocamera_on = false;
    bool animacio_on = false;
    bool direccio_nord = true;  // negatiu --> positiu
    

  public slots:
    void updatePosition();

  private:
  
    int printOglError(const char file[], int line, const char func[]);
   
    // Aquí tots els atributs privats que necessitis
};
